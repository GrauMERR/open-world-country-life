OPEN WORLD: COUNTRY LIFE — Android-ready project patch
====================================================

This package contains the Godot 4 source project from the supplied archive,
with small Android gameplay fixes:
- Weather now toggles once per press (not every frame while held).
- Added touch buttons for weather and jumping.
- Jump uses the same InputMap action on keyboard and touchscreen.
- Mouse capture is disabled on Android.

IMPORTANT: This is NOT a compiled APK. This environment does not have Godot
4 export templates, Android SDK, or JDK installed, so a genuine APK cannot
be built or tested here. Do not rename this ZIP to .apk.

BUILD AN APK
------------
1. Install Godot 4.3 or newer.
2. Install Android Studio and Android SDK platform/build-tools, plus JDK 17.
3. In Godot: Editor > Manage Export Templates > Download and Install.
4. Open this folder's project.godot.
5. In Editor > Editor Settings > Export > Android, set the Android SDK
   and Java SDK paths.
6. Project > Export. Add an Android preset if one is not already present.
7. Set a unique package identifier, e.g. org.example.countrylife.
8. For a test install, enable APK export and export the project to
   OPEN_WORLD_COUNTRY_LIFE.apk.
9. Install on an Android device (allow installation from the source used).

CONTROLS
--------
WASD / touch arrows — movement
E — enter/exit car
V — camera view
T — talk to nearby resident
F / touch F — weather
Space / touch ↑ — jump

SCOPE
-----
The supplied game remains an early 3D prototype: a countryside road,
trees, village, gas station, city block, simple traffic, NPCs, car,
day/night cycle and fog toggle. Features described as future plans in the
original README (large complete country, aircraft, ships, quests, online,
etc.) are not implemented in this build.
