extends Node3D

var player
var car
var sun: DirectionalLight3D
var time_of_day := 9.0
var weather := 0 # 0 clear, 1 fog
var status_label: Label
var npcs: Array[Node3D] = []
var nearby_npc: Node3D
var npc_message_timer := 0.0
var dialogue_text := ""

func _ready() -> void:
	_build_environment()
	_build_ground()
	_build_road()
	_build_trees()
	_build_village()
	_build_city()
	_build_car()
	_build_player()
	_build_ui()
	if not OS.has_feature("android"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _process(delta: float) -> void:
	time_of_day = fmod(time_of_day + delta * 0.015, 24.0)
	_update_sun()
	if Input.is_action_just_pressed("interact"):
		player.toggle_vehicle(car)
	if Input.is_action_just_pressed("camera_toggle"):
		player.toggle_camera()
	_update_npcs(delta)
	_update_traffic(delta)
	if Input.is_action_just_pressed("talk"):
		_talk_to_nearest_npc()
	if Input.is_action_just_pressed("weather_toggle"):
		weather = 1 - weather
		_update_weather()
	if npc_message_timer > 0.0:
		npc_message_timer = maxf(0.0, npc_message_timer - delta)
	if status_label:
		if npc_message_timer > 0.0:
			status_label.text = dialogue_text
			return
		var mode = "В машине" if player.in_vehicle else "Пешком"
		status_label.text = "OPEN WORLD: COUNTRY LIFE  |  %s  |  %02d:%02d  |  NPC рядом: %s" % [mode, int(time_of_day), int(fmod(time_of_day * 60.0, 60.0)), "T — разговор" if nearby_npc else "нет"]

func _build_environment() -> void:
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	e.sky = sky
	e.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.environment = e
	add_child(env)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-45, -30, 0)
	sun.light_energy = 1.2
	add_child(sun)

func _build_ground() -> void:
	var ground := StaticBody3D.new()
	ground.name = "Ground"
	var mesh := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(500, 500)
	mesh.mesh = plane
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.28, 0.48, 0.25)
	mat.roughness = 1.0
	mesh.material_override = mat
	ground.add_child(mesh)
	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(500, 1, 500)
	shape.shape = box
	shape.position.y = -0.5
	ground.add_child(shape)
	add_child(ground)

func _build_road() -> void:
	var road := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(12, 500)
	road.mesh = plane
	road.position.y = 0.025
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.16, 0.17, 0.18)
	road.material_override = m
	add_child(road)
	for z in range(-240, 250, 20):
		var stripe := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(0.25, 0.04, 8)
		stripe.mesh = box
		stripe.position = Vector3(0, 0.06, z)
		var sm := StandardMaterial3D.new()
		sm.albedo_color = Color(0.9, 0.85, 0.55)
		stripe.material_override = sm
		add_child(stripe)

func _build_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 8127
	for i in range(100):
		var x := rng.randf_range(-100, 100)
		var z := rng.randf_range(-220, 220)
		if abs(x) < 10:
			continue
		var trunk := MeshInstance3D.new()
		var cylinder := CylinderMesh.new()
		cylinder.top_radius = 0.18
		cylinder.bottom_radius = 0.28
		cylinder.height = 2.2
		trunk.mesh = cylinder
		trunk.position = Vector3(x, 1.1, z)
		var tm := StandardMaterial3D.new()
		tm.albedo_color = Color(0.28, 0.16, 0.08)
		trunk.material_override = tm
		add_child(trunk)
		var crown := MeshInstance3D.new()
		var cone := SphereMesh.new()
		cone.radius = rng.randf_range(1.1, 1.8)
		cone.height = cone.radius * 1.8
		crown.mesh = cone
		crown.position = Vector3(x, 3.0, z)
		var cm := StandardMaterial3D.new()
		cm.albedo_color = Color(0.12, rng.randf_range(0.3, 0.48), 0.16)
		crown.material_override = cm
		add_child(crown)

func _build_car() -> void:
	car = CharacterBody3D.new()
	car.set_script(load("res://scripts/car.gd"))
	car.position = Vector3(3, 0.8, 5)
	add_child(car)

func _build_player() -> void:
	player = CharacterBody3D.new()
	player.set_script(load("res://scripts/player.gd"))
	player.position = Vector3(-2, 1, 5)
	add_child(player)

func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	status_label = Label.new()
	status_label.position = Vector2(18, 14)
	status_label.add_theme_font_size_override("font_size", 18)
	layer.add_child(status_label)
	var help := Label.new()
	help.text = "WASD — движение   E — транспорт   T — разговор   V — камера   F — погода"
	help.position = Vector2(18, 42)
	help.add_theme_font_size_override("font_size", 15)
	layer.add_child(help)
	# Touch controls: buttons emulate the same InputMap actions as keyboard controls.
	_add_touch_button(layer, "◀", "move_left", Vector2(28, 565), Vector2(82, 82))
	_add_touch_button(layer, "▶", "move_right", Vector2(205, 565), Vector2(82, 82))
	_add_touch_button(layer, "▲", "move_forward", Vector2(116, 475), Vector2(82, 82))
	_add_touch_button(layer, "▼", "move_back", Vector2(116, 650), Vector2(82, 60))
	_add_touch_button(layer, "E", "interact", Vector2(1080, 590), Vector2(82, 82))
	_add_touch_button(layer, "V", "camera_toggle", Vector2(1170, 500), Vector2(82, 72))
	_add_touch_button(layer, "T", "talk", Vector2(1080, 490), Vector2(82, 72))
	_add_touch_button(layer, "F", "weather_toggle", Vector2(1170, 590), Vector2(82, 72))
	_add_touch_button(layer, "↑", "jump", Vector2(980, 590), Vector2(82, 72))

func _add_touch_button(layer: CanvasLayer, caption: String, action: String, pos: Vector2, dimensions: Vector2) -> void:
	var button := Button.new()
	button.text = caption
	button.position = pos
	button.size = dimensions
	button.add_theme_font_size_override("font_size", 26)
	button.modulate = Color(1, 1, 1, 0.82)
	button.button_down.connect(func(): Input.action_press(action))
	button.button_up.connect(func(): Input.action_release(action))
	layer.add_child(button)

func _update_sun() -> void:
	var daylight := clampf(sin((time_of_day - 6.0) / 12.0 * PI), 0.08, 1.0)
	sun.light_energy = daylight * 1.4
	sun.rotation_degrees.x = -((time_of_day - 6.0) / 24.0) * 360.0

func _update_weather() -> void:
	var env_node := get_node_or_null("WorldEnvironment") as WorldEnvironment
	if env_node and env_node.environment:
		env_node.environment.fog_enabled = weather == 1
		env_node.environment.fog_density = 0.012 if weather == 1 else 0.0


func _build_village() -> void:
	# Небольшая деревня расположена справа от главной трассы.
	var village_road := MeshInstance3D.new()
	var road_mesh := BoxMesh.new()
	road_mesh.size = Vector3(78, 0.12, 7)
	village_road.mesh = road_mesh
	village_road.position = Vector3(48, 0.04, 18)
	var road_mat := StandardMaterial3D.new()
	road_mat.albedo_color = Color(0.25, 0.25, 0.23)
	village_road.material_override = road_mat
	add_child(village_road)
	var house_positions := [Vector3(25,0,5), Vector3(43,0,5), Vector3(62,0,5), Vector3(31,0,34), Vector3(53,0,34), Vector3(72,0,34)]
	for i in range(house_positions.size()):
		_create_house(house_positions[i], i)
	_create_service_station(Vector3(70, 0, 18))
	_create_shop(Vector3(25, 0, 20))
	_create_npc(Vector3(39, 0, 15), Color(0.75, 0.32, 0.18), 7.0)
	_create_npc(Vector3(53, 0, 24), Color(0.22, 0.48, 0.78), 5.0)
	_create_npc(Vector3(30, 0, 28), Color(0.35, 0.65, 0.32), 6.0)

func _create_house(pos: Vector3, index: int) -> void:
	var house := Node3D.new()
	house.position = pos
	add_child(house)
	var colors := [Color(0.78,0.66,0.48), Color(0.68,0.73,0.72), Color(0.78,0.55,0.42)]
	var wall := BoxMesh.new()
	wall.size = Vector3(10, 5, 8)
	_add_mesh(house, wall, Vector3(0,2.5,0), colors[index % colors.size()])
	var roof := BoxMesh.new()
	roof.size = Vector3(11, 0.7, 9)
	_add_mesh(house, roof, Vector3(0,5.25,0), Color(0.28,0.16,0.12))
	var door := BoxMesh.new()
	door.size = Vector3(1.3,2.5,0.15)
	_add_mesh(house, door, Vector3(0,1.25,-4.08), Color(0.22,0.12,0.07))
	var window_mesh := BoxMesh.new()
	window_mesh.size = Vector3(1.8,1.4,0.16)
	_add_mesh(house, window_mesh, Vector3(-3,3,-4.1), Color(0.35,0.65,0.78))

func _create_shop(pos: Vector3) -> void:
	var shop := Node3D.new()
	shop.position = pos
	add_child(shop)
	var body := BoxMesh.new()
	body.size = Vector3(11,4.5,8)
	_add_mesh(shop, body, Vector3(0,2.25,0), Color(0.78,0.72,0.48))
	var roof := BoxMesh.new()
	roof.size = Vector3(12,0.5,9)
	_add_mesh(shop, roof, Vector3(0,4.75,0), Color(0.55,0.16,0.12))
	_add_sign(shop, "МАГАЗИН", Vector3(0,5.7,-4.2), Color(0.12,0.12,0.12))

func _create_service_station(pos: Vector3) -> void:
	var station := Node3D.new()
	station.position = pos
	add_child(station)
	var canopy := BoxMesh.new()
	canopy.size = Vector3(13,0.5,8)
	_add_mesh(station, canopy, Vector3(0,4.2,0), Color(0.85,0.18,0.12))
	for x in [-5.0, 5.0]:
		var pillar := BoxMesh.new()
		pillar.size = Vector3(0.5,4,0.5)
		_add_mesh(station, pillar, Vector3(x,2,0), Color(0.8,0.8,0.75))
	for x in [-3.0, 3.0]:
		var pump := BoxMesh.new()
		pump.size = Vector3(1.1,1.8,0.8)
		_add_mesh(station, pump, Vector3(x,0.9,2.2), Color(0.85,0.85,0.82))
	_add_sign(station, "ЗАПРАВКА", Vector3(0,5.2,-4.5), Color(0.9,0.9,0.9))

func _add_mesh(parent: Node3D, mesh_resource: Mesh, pos: Vector3, color: Color) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.mesh = mesh_resource
	instance.position = pos
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.9
	instance.material_override = material
	parent.add_child(instance)
	return instance

func _add_sign(parent: Node3D, caption: String, pos: Vector3, color: Color) -> void:
	var sign := Label3D.new()
	sign.text = caption
	sign.position = pos
	sign.font_size = 48
	sign.pixel_size = 0.01
	sign.modulate = color
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	parent.add_child(sign)

func _create_npc(pos: Vector3, shirt_color: Color, patrol_radius: float) -> void:
	var npc := Node3D.new()
	npc.position = pos
	npc.set_meta("home", pos)
	npc.set_meta("phase", randf() * TAU)
	npc.set_meta("radius", patrol_radius)
	npc.set_meta("shirt", shirt_color)
	var torso := CapsuleMesh.new()
	torso.radius = 0.42
	torso.height = 1.35
	_add_mesh(npc, torso, Vector3(0,1.05,0), shirt_color)
	var head := SphereMesh.new()
	head.radius = 0.3
	head.height = 0.6
	_add_mesh(npc, head, Vector3(0,1.95,0), Color(0.82,0.65,0.5))
	add_child(npc)
	npcs.append(npc)

func _update_npcs(delta: float) -> void:
	nearby_npc = null
	if player == null or player.in_vehicle:
		return
	var nearest := 999.0
	for npc in npcs:
		var home: Vector3 = npc.get_meta("home")
		var phase: float = npc.get_meta("phase") + Time.get_ticks_msec() * 0.00025
		var radius: float = npc.get_meta("radius")
		npc.position = home + Vector3(cos(phase) * radius, 0, sin(phase * 0.7) * radius)
		npc.rotation.y = -sin(phase)
		var distance := player.global_position.distance_to(npc.global_position)
		if distance < nearest and distance < 4.0:
			nearest = distance
			nearby_npc = npc

func _talk_to_nearest_npc() -> void:
	if nearby_npc and status_label:
		var lines := ["Привет! Добро пожаловать в нашу деревню.", "Говорят, за городом есть большой порт.", "На заправке можно будет пополнить топливо."]
		dialogue_text = "Житель: " + lines[randi() % lines.size()]
		npc_message_timer = 3.5
		status_label.text = dialogue_text


# Городской район прототипа: здания, перекрёсток, фонари и простое движение машин.
var traffic_cars: Array[Node3D] = []

func _build_city() -> void:
	var city_x := -72.0
	# Главная городская улица пересекает загородную трассу.
	var cross_road := MeshInstance3D.new()
	var cross_mesh := BoxMesh.new()
	cross_mesh.size = Vector3(150, 0.14, 14)
	cross_road.mesh = cross_mesh
	cross_road.position = Vector3(city_x, 0.04, 0)
	_add_mesh(self, cross_mesh, Vector3(city_x, 0.04, 0), Color(0.17, 0.18, 0.19))
	# Тротуары по обеим сторонам улицы.
	for side in [-1.0, 1.0]:
		var sidewalk := BoxMesh.new()
		sidewalk.size = Vector3(150, 0.22, 3.2)
		_add_mesh(self, sidewalk, Vector3(city_x, 0.12, side * 9.0), Color(0.52, 0.52, 0.49))
	# Разметка перекрёстка и пешеходные переходы.
	for i in range(9):
		var stripe := BoxMesh.new()
		stripe.size = Vector3(1.1, 0.035, 7.0)
		_add_mesh(self, stripe, Vector3(city_x - 7.0 + i * 1.75, 0.14, -9.0), Color(0.92, 0.92, 0.86))
		_add_mesh(self, stripe, Vector3(city_x - 7.0 + i * 1.75, 0.14, 9.0), Color(0.92, 0.92, 0.86))
	for z in [-5.0, 5.0]:
		for x in range(-140, 1, 10):
			var dash := BoxMesh.new()
			dash.size = Vector3(5.0, 0.035, 0.22)
			_add_mesh(self, dash, Vector3(float(x), 0.14, z), Color(0.9, 0.82, 0.45))
	# Кварталы: здания по обеим сторонам улицы.
	var building_data := [
		[Vector3(-132,0,-28), Vector3(19,17,15), Color(0.68,0.72,0.75)],
		[Vector3(-105,0,-30), Vector3(20,25,17), Color(0.76,0.65,0.52)],
		[Vector3(-75,0,-29), Vector3(21,20,16), Color(0.58,0.67,0.72)],
		[Vector3(-43,0,-30), Vector3(22,29,17), Color(0.72,0.72,0.66)],
		[Vector3(-132,0,29), Vector3(19,22,15), Color(0.72,0.61,0.55)],
		[Vector3(-103,0,30), Vector3(20,18,17), Color(0.62,0.7,0.62)],
		[Vector3(-73,0,29), Vector3(21,27,16), Color(0.68,0.68,0.76)],
		[Vector3(-43,0,30), Vector3(22,19,17), Color(0.76,0.69,0.57)]
	]
	for data in building_data:
		_create_city_building(data[0], data[1], data[2])
	# Фонари вдоль улицы.
	for x in range(-140, 1, 20):
		for side in [-1.0, 1.0]:
			var pole := CylinderMesh.new()
			pole.top_radius = 0.09
			pole.bottom_radius = 0.13
			pole.height = 6.5
			_add_mesh(self, pole, Vector3(float(x), 3.25, side * 11.0), Color(0.22,0.23,0.24))
			var arm := BoxMesh.new()
			arm.size = Vector3(1.8,0.12,0.12)
			_add_mesh(self, arm, Vector3(float(x) + 0.75, 6.35, side * 11.0), Color(0.22,0.23,0.24))
			var lamp := SphereMesh.new()
			lamp.radius = 0.24
			lamp.height = 0.35
			_add_mesh(self, lamp, Vector3(float(x) + 1.5, 6.2, side * 11.0), Color(1.0,0.88,0.55))
	# Светофоры на углах перекрёстка.
	for x_side in [-1.0, 1.0]:
		for z_side in [-1.0, 1.0]:
			var pole_mesh := CylinderMesh.new()
			pole_mesh.top_radius = 0.08
			pole_mesh.bottom_radius = 0.12
			pole_mesh.height = 5.0
			_add_mesh(self, pole_mesh, Vector3(city_x + x_side * 10.0, 2.5, z_side * 10.0), Color(0.16,0.17,0.18))
			var signal := BoxMesh.new()
			signal.size = Vector3(0.65,1.8,0.5)
			_add_mesh(self, signal, Vector3(city_x + x_side * 10.0, 4.7, z_side * 10.0), Color(0.12,0.12,0.12))
			for lamp_i in range(3):
				var bulb := SphereMesh.new()
				bulb.radius = 0.19
				bulb.height = 0.22
				var bulb_color := Color(0.85,0.12,0.08) if lamp_i == 0 else (Color(0.9,0.65,0.08) if lamp_i == 1 else Color(0.12,0.72,0.2))
				_add_mesh(self, bulb, Vector3(city_x + x_side * 10.0, 5.25 - lamp_i * 0.55, z_side * 10.32), bulb_color)
	# Несколько машин движутся по городской улице.
	for i in range(4):
		var traffic := Node3D.new()
		traffic.set_meta("lane_z", -3.0 if i % 2 == 0 else 3.0)
		traffic.set_meta("direction", 1.0 if i % 2 == 0 else -1.0)
		traffic.position = Vector3(-140.0 + float(i) * 35.0, 0.0, float(traffic.get_meta("lane_z")))
		var car_body := BoxMesh.new()
		car_body.size = Vector3(4.0,1.0,1.8)
		_add_mesh(traffic, car_body, Vector3(0,0.75,0), [Color(0.8,0.15,0.1),Color(0.15,0.35,0.8),Color(0.8,0.75,0.2),Color(0.8,0.8,0.8)][i])
		var car_top := BoxMesh.new()
		car_top.size = Vector3(2.0,0.8,1.5)
		_add_mesh(traffic, car_top, Vector3(0,1.55,0), Color(0.18,0.2,0.22))
		traffic.set_meta("speed", 7.0 + float(i % 3) * 1.5)
		add_child(traffic)
		traffic_cars.append(traffic)
	_add_sign(self, "ГОРОД", Vector3(city_x, 8.0, -42.0), Color(1,1,1))

func _create_city_building(pos: Vector3, dimensions: Vector3, color: Color) -> void:
	var building := Node3D.new()
	building.position = pos
	add_child(building)
	var body := BoxMesh.new()
	body.size = dimensions
	_add_mesh(building, body, Vector3(0, dimensions.y * 0.5, 0), color)
	var roof := BoxMesh.new()
	roof.size = Vector3(dimensions.x + 0.8, 0.5, dimensions.z + 0.8)
	_add_mesh(building, roof, Vector3(0, dimensions.y + 0.25, 0), Color(0.22,0.24,0.27))
	# Окна на фасаде, обращённом к улице (ось Z).
	var floors := int(dimensions.y / 4.0)
	var columns := int(dimensions.x / 4.0)
	for floor_i in range(floors):
		for col_i in range(columns):
			var window_mesh := BoxMesh.new()
			window_mesh.size = Vector3(1.5,1.6,0.12)
			var wx := -dimensions.x * 0.5 + 2.5 + float(col_i) * 4.0
			var wy := 2.5 + float(floor_i) * 4.0
			_add_mesh(building, window_mesh, Vector3(wx, wy, -dimensions.z * 0.5 - 0.08), Color(0.24,0.48,0.62))

func _update_traffic(delta: float) -> void:
	for traffic in traffic_cars:
		var direction: float = traffic.get_meta("direction")
		var speed: float = traffic.get_meta("speed")
		traffic.position.x += direction * speed * delta
		if traffic.position.x > -2.0:
			traffic.position.x = -142.0
		elif traffic.position.x < -142.0:
			traffic.position.x = -2.0
