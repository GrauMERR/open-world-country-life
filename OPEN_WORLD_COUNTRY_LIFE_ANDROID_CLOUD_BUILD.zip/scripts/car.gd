extends CharacterBody3D

var occupied := false
const ACCELERATION := 18.0
const MAX_SPEED := 26.0
const TURN_SPEED := 1.8
var speed := 0.0
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")

func _ready() -> void:
	var chassis := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(2.0, 0.8, 4.0)
	chassis.mesh = box
	chassis.position.y = 0.7
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.78, 0.16, 0.08)
	chassis.material_override = mat
	add_child(chassis)
	var cabin := MeshInstance3D.new()
	var cab := BoxMesh.new()
	cab.size = Vector3(1.6, 0.8, 1.8)
	cabin.mesh = cab
	cabin.position = Vector3(0, 1.45, -0.25)
	cabin.material_override = mat
	add_child(cabin)
	var shape := CollisionShape3D.new()
	var collision := BoxShape3D.new()
	collision.size = Vector3(2.0, 1.4, 4.0)
	shape.shape = collision
	shape.position.y = 0.7
	add_child(shape)

func _physics_process(delta: float) -> void:
	if occupied:
		var throttle := Input.get_axis("move_back", "move_forward")
		var steering := Input.get_axis("move_left", "move_right")
		speed = move_toward(speed, throttle * MAX_SPEED, ACCELERATION * delta)
		if abs(speed) > 0.5:
			rotate_y(-steering * TURN_SPEED * delta * sign(speed))
		velocity.x = -global_transform.basis.z.x * speed
		velocity.z = -global_transform.basis.z.z * speed
	else:
		speed = move_toward(speed, 0, ACCELERATION * delta)
		velocity.x = 0
		velocity.z = 0
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = 0
	move_and_slide()
