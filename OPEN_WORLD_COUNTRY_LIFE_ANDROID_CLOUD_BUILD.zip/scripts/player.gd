extends CharacterBody3D

const SPEED := 7.0
const JUMP_VELOCITY := 4.5
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity")
var camera_pivot: Node3D
var camera: Camera3D
var in_vehicle := false
var current_car: CharacterBody3D
var first_person := false

func _ready() -> void:
	var capsule := CapsuleMesh.new()
	var body_mesh := MeshInstance3D.new()
	body_mesh.mesh = capsule
	body_mesh.position.y = 0.9
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.18, 0.38, 0.8)
	body_mesh.material_override = mat
	add_child(body_mesh)
	var shape := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.height = 1.8
	shape.shape = cap
	shape.position.y = 0.9
	add_child(shape)
	camera_pivot = Node3D.new()
	camera_pivot.position.y = 1.5
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 2.0, 6.0)
	camera.rotation_degrees.x = -12
	camera.current = true
	camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
	if in_vehicle:
		global_position = current_car.global_position + Vector3(0, 1.5, 0)
		return
	if not is_on_floor():
		velocity.y -= gravity * delta
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
	if direction:
		velocity.x = direction.x * SPEED
		velocity.z = direction.z * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		velocity.z = move_toward(velocity.z, 0, SPEED)
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	move_and_slide()

func toggle_vehicle(vehicle: CharacterBody3D) -> void:
	if in_vehicle:
		in_vehicle = false
		current_car.occupied = false
		global_position = current_car.global_position + Vector3(2.5, 0.5, 0)
		visible = true
		return
	if global_position.distance_to(vehicle.global_position) < 5.0 and not vehicle.occupied:
		in_vehicle = true
		current_car = vehicle
		vehicle.occupied = true
		visible = false

func toggle_camera() -> void:
	first_person = not first_person
	camera.position = Vector3(0, 0.15, 0) if first_person else Vector3(0, 2.0, 6.0)
	camera.rotation_degrees.x = 0 if first_person else -12
